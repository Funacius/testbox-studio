# Exported Testbox Selenium/unittest suite

Requires Python 3.12+, a supported installed browser, and a reachable test site.
This ZIP includes its Python runtime; Testbox Studio and the original repository
are not required. Selenium Manager may need internet to obtain a matching driver.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe level1/test_cases.py --headless
.\.venv\Scripts\python.exe level2/test_cases.py --headless
```

Use --browser chrome|edge|opera|both, --base-url URL, --output DIR, --list,
--case CASE-ID (repeatable), or omit --headless for a visible temporary browser.
Only levels included during export are available. CLI runs use unittest and write
JSON/CSV/HTML reports with evidence. Standard discovery is also supported:
`python -m unittest level1.test_cases -v` (visible browser by default; set
TESTBOX_HEADLESS=1 for background discovery). Discovery uses unittest's own
reporting; use test_cases.py directly for the full HTML/CSV report.

- Level 1: URLs, locators and action definitions live in level1/program.py.
  Edit that Python file to change the test program.
- Level 2: action definitions live in level2/cases.json and site items in
  level2/config/site.json. Changes to those files require no Python edits.
- Each data/case-CASE-ID.csv is read at run time, including input and expected values.
  Literal step inputs/oracles appear in step_N_value / step_N_expected columns.
  You can edit or add data rows. Keep text values, empty strings and spaces exact.
- data/shared_variables.csv supplies defaults. Precedence is shared defaults,
  TESTBOX_VAR_name environment variables, then per-row values. Reserved base_url,
  run_id, case_id and runtime_id are set by the runner.
- Sparse datasets have an internal __testbox_present column listing keys present
  in that row. Keep it to distinguish missing from explicitly empty cells; leave
  blank on a new row to use all the data columns on that row.
- Upload files present at export are copied into assets/. Runtime/environment
  upload paths must exist on the target machine. See manifest.json for warnings.
- Native Gradebook cases retain their original fields and expected JSON in CSV;
  they still need Moodle, its fixture and an editing teacher. Level 1 uses
  level1/settings.py; Level 2 uses level2/config/gradebook.json.
- Run-configuration credentials are not copied by the GUI export. Values already
  saved in your dataset or project variables ARE included; review data before
  sharing. You can supply credentials through TESTBOX_VAR_username/password
  (general steps) or MOODLE_USERNAME/PASSWORD (native Gradebook).
- Slow playback and interactive pauses affect elapsed timers. Case duration is
  not a response-time benchmark. Exported batch runs ignore step breakpoints.

The package preserves assertions. An intentionally invalid expected value must
produce FAIL; do not replace expected data just to turn a failing case green.
