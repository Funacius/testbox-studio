"""Level 1: edit URLs, locator aliases and action definitions here."""

SETTINGS = {'base_url': 'http://127.0.0.1:9542',
 'locators': {'export_DEMO-LOGIN_2': 'id=username',
              'export_DEMO-LOGIN_3': 'id=password',
              'export_DEMO-LOGIN_4': 'id=login',
              'export_DEMO-LOGIN_5': 'id=message'},
 'upload_assets': {}}

CASES = [{'record': {'case_id': 'DEMO-LOGIN',
             'title': 'Data-driven login',
             'workflow': 'steps',
             'item_name': '',
             'minimum': '',
             'maximum': '',
             'grade_type': '',
             'inputs_json': '{}',
             'expected_json': '{}',
             'expected_result': '',
             'actions_json': '[\n'
                             '  {\n'
                             '    "id": "5069450e6b3c48c1a0f1b2cd30bfe8fb",\n'
                             '    "enabled": true,\n'
                             '    "phase": "setup",\n'
                             '    "command": "open",\n'
                             '    "target": "${base_url}",\n'
                             '    "value": "",\n'
                             '    "expected": "",\n'
                             '    "timeout": 15.0,\n'
                             '    "breakpoint": false,\n'
                             '    "description": ""\n'
                             '  },\n'
                             '  {\n'
                             '    "id": "179cf57bcd334e53b4619f7877a8f5f0",\n'
                             '    "enabled": true,\n'
                             '    "phase": "test",\n'
                             '    "command": "type",\n'
                             '    "target": "@export_DEMO-LOGIN_2",\n'
                             '    "value": "${username}",\n'
                             '    "expected": "",\n'
                             '    "timeout": 15.0,\n'
                             '    "breakpoint": false,\n'
                             '    "description": ""\n'
                             '  },\n'
                             '  {\n'
                             '    "id": "436e3f8fb98f4f27b094592c96f3efc1",\n'
                             '    "enabled": true,\n'
                             '    "phase": "test",\n'
                             '    "command": "type",\n'
                             '    "target": "@export_DEMO-LOGIN_3",\n'
                             '    "value": "${password}",\n'
                             '    "expected": "",\n'
                             '    "timeout": 15.0,\n'
                             '    "breakpoint": false,\n'
                             '    "description": ""\n'
                             '  },\n'
                             '  {\n'
                             '    "id": "daffaa780ff24fb8a86f4c3e23e5020e",\n'
                             '    "enabled": true,\n'
                             '    "phase": "test",\n'
                             '    "command": "click",\n'
                             '    "target": "@export_DEMO-LOGIN_4",\n'
                             '    "value": "",\n'
                             '    "expected": "",\n'
                             '    "timeout": 15.0,\n'
                             '    "breakpoint": false,\n'
                             '    "description": ""\n'
                             '  },\n'
                             '  {\n'
                             '    "id": "05a99bf073164723935880f9813a8eb4",\n'
                             '    "enabled": true,\n'
                             '    "phase": "test",\n'
                             '    "command": "assert_text",\n'
                             '    "target": "@export_DEMO-LOGIN_5",\n'
                             '    "value": "",\n'
                             '    "expected": "${expected_message}",\n'
                             '    "timeout": 15.0,\n'
                             '    "breakpoint": false,\n'
                             '    "description": ""\n'
                             '  }\n'
                             ']\n',
             'dataset_json': '[]',
             'variables_json': '{}',
             'precondition': '',
             'notes': 'Imported steps require review before execution.',
             'known_defect': '',
             'source_sheet': '',
             'source_row': '2',
             'original_case_id': 'DEMO-LOGIN',
             'folder_path': '',
             'steps_json': '[{"action": "open", "expected": "", "source_row": 2}, {"action": '
                           '"type", "expected": "", "source_row": 3}, {"action": "type", '
                           '"expected": "", "source_row": 4}, {"action": "click", "expected": "", '
                           '"source_row": 5}, {"action": "assert_text", "expected": '
                           '"${expected_message}", "source_row": 6}]'},
  'data': 'data/case-DEMO-LOGIN.csv',
  'presence_column': None}]
