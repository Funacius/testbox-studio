"""Level 1: edit URLs, locator aliases and action definitions here."""

SETTINGS = {'base_url': 'http://127.0.0.1:9542',
 'locators': {'export_DEMO-LOGIN_2': 'id=username',
              'export_DEMO-LOGIN_3': 'id=password',
              'export_DEMO-LOGIN_4': 'id=login',
              'export_DEMO-LOGIN_5': 'id=message'},
 'upload_assets': {}}

CASES = [{'record': {'case_id': 'DEMO-LOGIN',
             'title': 'Data-driven login',
             'workflow': 'steps',
             'item_name': '',
             'minimum': '',
             'maximum': '',
             'grade_type': '',
             'inputs_json': '{}',
             'expected_json': '{}',
             'expected_result': '',
             'actions_json': '[\n'
                             '  {\n'
                             '    "id": "c2a04ec7772a4d4f80a9601a84ef996c",\n'
                             '    "enabled": true,\n'
                             '    "phase": "setup",\n'
                             '    "command": "open",\n'
                             '    "target": "${base_url}",\n'
                             '    "value": "",\n'
                             '    "expected": "",\n'
                             '    "timeout": 15.0,\n'
                             '    "breakpoint": false,\n'
                             '    "description": ""\n'
                             '  },\n'
                             '  {\n'
                             '    "id": "6f89792c157949b5a7fad569080a97a3",\n'
                             '    "enabled": true,\n'
                             '    "phase": "test",\n'
                             '    "command": "type",\n'
                             '    "target": "@export_DEMO-LOGIN_2",\n'
                             '    "value": "${username}",\n'
                             '    "expected": "",\n'
                             '    "timeout": 15.0,\n'
                             '    "breakpoint": false,\n'
                             '    "description": ""\n'
                             '  },\n'
                             '  {\n'
                             '    "id": "d48394dc881b4f8eb4fea38a45cb29ce",\n'
                             '    "enabled": true,\n'
                             '    "phase": "test",\n'
                             '    "command": "type",\n'
                             '    "target": "@export_DEMO-LOGIN_3",\n'
                             '    "value": "${password}",\n'
                             '    "expected": "",\n'
                             '    "timeout": 15.0,\n'
                             '    "breakpoint": false,\n'
                             '    "description": ""\n'
                             '  },\n'
                             '  {\n'
                             '    "id": "2246c0a6925b40b59f035d9331de2a76",\n'
                             '    "enabled": true,\n'
                             '    "phase": "test",\n'
                             '    "command": "click",\n'
                             '    "target": "@export_DEMO-LOGIN_4",\n'
                             '    "value": "",\n'
                             '    "expected": "",\n'
                             '    "timeout": 15.0,\n'
                             '    "breakpoint": false,\n'
                             '    "description": ""\n'
                             '  },\n'
                             '  {\n'
                             '    "id": "811244e9328a43cfbdafb55c97700476",\n'
                             '    "enabled": true,\n'
                             '    "phase": "test",\n'
                             '    "command": "assert_text",\n'
                             '    "target": "@export_DEMO-LOGIN_5",\n'
                             '    "value": "",\n'
                             '    "expected": "${expected_message}",\n'
                             '    "timeout": 15.0,\n'
                             '    "breakpoint": false,\n'
                             '    "description": ""\n'
                             '  }\n'
                             ']\n',
             'dataset_json': '[]',
             'variables_json': '{}',
             'precondition': '',
             'notes': 'Imported steps require review before execution.',
             'known_defect': '',
             'source_sheet': '',
             'source_row': '2',
             'original_case_id': 'DEMO-LOGIN',
             'folder_path': '',
             'steps_json': '[{"action": "open", "expected": "", "source_row": 2}, {"action": '
                           '"type", "expected": "", "source_row": 3}, {"action": "type", '
                           '"expected": "", "source_row": 4}, {"action": "click", "expected": "", '
                           '"source_row": 5}, {"action": "assert_text", "expected": '
                           '"${expected_message}", "source_row": 6}]'},
  'data': 'data/case-DEMO-LOGIN.csv',
  'presence_column': None}]
