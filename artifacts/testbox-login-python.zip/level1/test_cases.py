"""Exported Selenium/unittest suite. Data and expected values are read from CSV."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "runtime"))
from automation.export_runtime import cli, discovery_suite

LEVEL = 1

def load_tests(loader, tests, pattern):
    return discovery_suite(ROOT, LEVEL)

if __name__ == "__main__":
    raise SystemExit(cli(ROOT, LEVEL))
